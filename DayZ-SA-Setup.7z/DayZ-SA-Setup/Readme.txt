Batch file for setup of dayz SA server

1.Download the tool from http://dayzsalauncher.com/#/tools
2.Put the path to the EXE. in the batch file.
3.Add the mods that you will be running on your server.